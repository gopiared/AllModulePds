﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;
namespace COMInterOp
{
    class Program
    {
        static void Main(string[] args)
        {
            var wordApplication = new Microsoft.Office.Interop.Word.Application();
            wordApplication.Visible = true;
            object missing = System.Reflection.Missing.Value;
            object file = @"D:\Myfile.doc";
            object visible = true;
            object readOnly = false;

            //Classic Way
            //Document aDoc = wordApplication.Documents.Open(ref file, ref missing, ref readOnly,
            //    ref missing, ref missing, ref missing, ref missing,
            //    ref missing, ref missing, ref missing, ref missing,
            //    ref visible, ref missing, ref missing, ref missing,
            //    ref missing); 

            //.NET optional and named parameters make this much easier:
            var betterWay = wordApplication.Documents.Open(file, ReadOnly: true, Visible: true);
            betterWay.Activate();
        }
    }
}
